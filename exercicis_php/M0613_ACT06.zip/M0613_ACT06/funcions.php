<?php
/**
 * Funcions pròpies del projecte.
 * Aquest fitxer NO escriu res a la pantalla.
 */

/**
 * Recull un camp de text del formulari ja net d'espais.
 *
 * @param string $camp Nom del camp (l'atribut name del formulari)
 * @param string $defecte Valor si el camp no ha arribat
 * @return string El valor net
 */
function camp(string $camp, string $defecte = ''): string
{
    return trim($_POST[$camp] ?? $defecte);
}

/**
 * Converteix la clau de l'array en una etiqueta llegible.
 *
 * @param string $clau Clau de l'array ('codiPostal', 'naixement'...)
 * @return string Etiqueta per mostrar a la taula
 */
function etiqueta(string $clau): string
{
    $noms = [
        'nom'         => 'Nom',
        'cognom'      => 'Cognom',
        'naixement'   => 'Data de naixement',
        'telefon'     => 'Telèfon',
        'usuari'      => 'Usuari',
        'correu'      => 'Correu electrònic',
        'carrer'      => 'Carrer i número',
        'poblacio'    => 'Població',
        'codiPostal'  => 'Codi postal',
        'tipusClient' => 'Tipus de client',
        'origen'      => 'Com ens has conegut',
        'bulleti'     => 'Vol rebre ofertes',
    ];

    return $noms[$clau] ?? ucfirst($clau);
}

/**
 * Indica si una casella de verificació s'ha marcat al formulari.
 *
 * @param string $camp Nom de la casella (l'atribut name del formulari)
 * @return bool true si s'ha marcat, false si no ha arribat
 */
function casella(string $camp): bool
{
    return isset($_POST[$camp]);
}

/**
 * Escapa un text perquè es pugui mostrar de forma segura dins l'HTML.
 *
 * @param string $text Text a escapar
 * @return string Text amb els caràcters especials convertits
 */
function esc(string $text): string
{
    return htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
}
