<?php
/**
 * Configuració general del projecte.
 * Aquest fitxer NO escriu res a la pantalla.
 */

// Dades de la botiga
const BOTIGA_NOM    = 'Botiga coloradeishon';
const BOTIGA_LEMA   = 'La botiga mes colorida';
const BOTIGA_CORREU = 'info@coloradeishon.cat';

// Regles de validació
const MIN_USUARI = 4;
const MIN_CLAU   = 6;

// Rutes
const FULL_ESTILS   = 'estils.css';
const PAG_FORMULARI = 'registre.php';
